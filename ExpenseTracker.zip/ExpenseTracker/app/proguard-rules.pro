# Keep Room entities
-keep class com.expensetracker.data.model.** { *; }

# Apache POI
-dontwarn org.apache.poi.**
-keep class org.apache.poi.** { *; }
