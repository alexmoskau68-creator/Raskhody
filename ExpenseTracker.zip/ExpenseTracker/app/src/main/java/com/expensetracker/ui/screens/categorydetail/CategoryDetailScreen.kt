package com.expensetracker.ui.screens.categorydetail

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.expensetracker.data.model.Category
import com.expensetracker.data.model.ReceiptItem
import com.expensetracker.data.repository.ExpenseRepository
import com.expensetracker.ui.theme.TealDark
import com.expensetracker.utils.FormatUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryDetailScreen(
    categoryId: String,
    startMillis: Long,
    endMillis: Long,
    repository: ExpenseRepository,
    onBack: () -> Unit
) {
    var category by remember { mutableStateOf<Category?>(null) }
    var items by remember { mutableStateOf<List<ReceiptItem>>(emptyList()) }
    var total by remember { mutableStateOf(0.0) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(categoryId, startMillis, endMillis) {
        val cats = repository.getCategoriesOnce()
        category = cats.find { it.id == categoryId }
        val (sum, list) = repository.getCategorySummaryForPeriod(categoryId, startMillis, endMillis)
        total = sum
        items = list
        isLoading = false
    }

    val bgColor = try {
        Color(android.graphics.Color.parseColor(category?.colorHex ?: "#2196F3"))
    } catch (_: Exception) {
        Color(0xFF2196F3)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Назад",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        }
    ) { padding ->
        if (isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header with illustration placeholder
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .background(
                            Brush.verticalGradient(
                                listOf(bgColor.copy(0.9f), bgColor.copy(0.6f))
                            )
                        )
                        .padding(padding)
                ) {
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(20.dp)
                    ) {
                        Text(
                            category?.icon ?: "📦",
                            fontSize = 48.sp
                        )
                        Text(
                            category?.name ?: "Категория",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp
                        )
                        Text(
                            FormatUtils.formatMonth(startMillis),
                            color = Color.White.copy(0.85f),
                            fontSize = 14.sp
                        )
                    }
                }

                // Items list
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .offset(y = (-16).dp)
                        .background(
                            Color.White,
                            RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
                        )
                        .padding(top = 8.dp),
                    contentPadding = PaddingValues(bottom = 32.dp)
                ) {
                    items(items) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.name, fontWeight = FontWeight.Medium)
                                Text(
                                    "${item.quantity} × ${FormatUtils.formatMoney(item.price / item.quantity.coerceAtLeast(0.01))}",
                                    fontSize = 13.sp,
                                    color = Color.Gray
                                )
                            }
                            Text(
                                FormatUtils.formatMoney(item.price),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        HorizontalDivider(
                            modifier = Modifier.padding(start = 20.dp),
                            color = Color(0xFFEEEEEE)
                        )
                    }

                    item {
                        Spacer(Modifier.height(12.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Итого", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                FormatUtils.formatMoney(total),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }

                    if (items.isEmpty()) {
                        item {
                            Text(
                                "Нет покупок в этой категории за выбранный период",
                                modifier = Modifier.padding(40.dp),
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }
    }
}
