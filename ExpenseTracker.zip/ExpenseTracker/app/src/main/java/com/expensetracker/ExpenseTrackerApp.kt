package com.expensetracker

import android.app.Application
import com.expensetracker.data.repository.ExpenseRepository

class ExpenseTrackerApp : Application() {
    lateinit var repository: ExpenseRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = ExpenseRepository(this)
    }
}
