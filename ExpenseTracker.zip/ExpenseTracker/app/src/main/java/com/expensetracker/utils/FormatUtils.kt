package com.expensetracker.utils

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object FormatUtils {
    private val moneyFormat = NumberFormat.getNumberInstance(Locale("ru", "RU")).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
    }

    private val dateFormat = SimpleDateFormat("d MMM yyyy", Locale("ru"))
    private val dateFormatShort = SimpleDateFormat("d MMM", Locale("ru"))
    private val dateTimeFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru"))
    private val monthFormat = SimpleDateFormat("LLLL", Locale("ru"))

    fun formatMoney(amount: Double): String {
        return "${moneyFormat.format(amount)} ₽"
    }

    fun formatMoneyShort(amount: Double): String {
        return if (amount >= 1000) {
            String.format(Locale("ru"), "%.2f т.р.", amount / 1000)
        } else {
            formatMoney(amount)
        }
    }

    fun formatDate(millis: Long): String = dateFormat.format(Date(millis))

    fun formatDateShort(millis: Long): String = dateFormatShort.format(Date(millis))

    fun formatDateTime(millis: Long): String = dateTimeFormat.format(Date(millis))

    fun formatMonth(millis: Long): String {
        val name = monthFormat.format(Date(millis))
        return name.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("ru")) else it.toString() }
    }

    fun getMonthName(calendar: Calendar = Calendar.getInstance()): String {
        return formatMonth(calendar.timeInMillis)
    }
}
