package com.expensetracker.ui.screens.categories

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.expensetracker.data.model.CategorySummary
import com.expensetracker.data.model.PeriodType
import com.expensetracker.data.repository.ExpenseRepository
import com.expensetracker.ui.theme.TealDark
import com.expensetracker.ui.theme.TealPrimary
import com.expensetracker.utils.FormatUtils
import kotlinx.coroutines.launch
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoriesScreen(
    repository: ExpenseRepository,
    onBack: () -> Unit,
    onCategoryClick: (String, Long, Long) -> Unit
) {
    var periodType by remember { mutableStateOf(PeriodType.CURRENT_MONTH) }
    var startMillis by remember { mutableStateOf(0L) }
    var endMillis by remember { mutableStateOf(0L) }
    var periodLabel by remember { mutableStateOf("Текущий месяц") }
    var summaries by remember { mutableStateOf<List<CategorySummary>>(emptyList()) }
    var total by remember { mutableStateOf(0.0) }
    var showPeriodSheet by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(true) }

    val scope = rememberCoroutineScope()

    fun loadData(type: PeriodType) {
        scope.launch {
            isLoading = true
            val (start, end, label) = when (type) {
                PeriodType.CURRENT_MONTH -> {
                    val r = repository.getCurrentMonthRange()
                    Triple(r.first, r.second, FormatUtils.getMonthName())
                }
                PeriodType.PREVIOUS_MONTH -> {
                    val r = repository.getPreviousMonthRange()
                    Triple(r.first, r.second, "Прошлый месяц")
                }
                PeriodType.LAST_30_DAYS -> {
                    val r = repository.getLastDaysRange(30)
                    Triple(r.first, r.second, "Последние 30 дней")
                }
                PeriodType.LAST_90_DAYS -> {
                    val r = repository.getLastDaysRange(90)
                    Triple(r.first, r.second, "Последние 90 дней")
                }
                PeriodType.YEAR_TO_DATE -> {
                    val r = repository.getYearToDateRange()
                    Triple(r.first, r.second, "С начала года")
                }
                else -> {
                    val r = repository.getCurrentMonthRange()
                    Triple(r.first, r.second, "Текущий месяц")
                }
            }
            startMillis = start
            endMillis = end
            periodLabel = label
            periodType = type

            val list = repository.getCategoryTotalsForPeriod(start, end)
            summaries = list
            total = list.sumOf { it.total }
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData(PeriodType.CURRENT_MONTH)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Категории") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = TealDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Period selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clickable { showPeriodSheet = true },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.DateRange, contentDescription = null, tint = TealPrimary)
                Spacer(Modifier.width(8.dp))
                Text(
                    periodLabel,
                    fontWeight = FontWeight.Medium,
                    color = TealDark
                )
            }

            if (isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                // Pie chart
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (summaries.isNotEmpty()) {
                        SimplePieChart(
                            data = summaries,
                            modifier = Modifier.size(180.dp)
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Всего", color = Color.Gray, fontSize = 13.sp)
                            Text(
                                FormatUtils.formatMoneyShort(total),
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            )
                        }
                    } else {
                        Text("Нет данных за период", color = Color.Gray)
                    }
                }

                // List
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(summaries) { sum ->
                        CategoryRow(
                            summary = sum,
                            onClick = {
                                onCategoryClick(sum.category.id, startMillis, endMillis)
                            }
                        )
                    }
                }
            }
        }
    }

    if (showPeriodSheet) {
        ModalBottomSheet(onDismissRequest = { showPeriodSheet = false }) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    "Выберите период",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 18.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                val options = listOf(
                    PeriodType.CURRENT_MONTH to FormatUtils.getMonthName(),
                    PeriodType.PREVIOUS_MONTH to "Прошлый месяц",
                    PeriodType.LAST_30_DAYS to "Последние 30 дней",
                    PeriodType.LAST_90_DAYS to "Последние 90 дней",
                    PeriodType.YEAR_TO_DATE to "С начала года"
                )

                options.forEach { (type, label) ->
                    val selected = periodType == type
                    Surface(
                        onClick = {
                            showPeriodSheet = false
                            loadData(type)
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) TealPrimary.copy(0.12f) else Color.Transparent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Text(
                            label,
                            modifier = Modifier.padding(14.dp),
                            color = if (selected) TealPrimary else Color.Unspecified,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun SimplePieChart(
    data: List<CategorySummary>,
    modifier: Modifier = Modifier
) {
    val total = data.sumOf { it.total }.toFloat().coerceAtLeast(0.01f)
    val colors = data.map {
        try {
            Color(android.graphics.Color.parseColor(it.category.colorHex))
        } catch (_: Exception) {
            TealPrimary
        }
    }

    Canvas(modifier = modifier) {
        val stroke = 28.dp.toPx()
        val diameter = size.minDimension - stroke
        val topLeft = Offset((size.width - diameter) / 2, (size.height - diameter) / 2)
        val arcSize = Size(diameter, diameter)

        var startAngle = -90f
        data.forEachIndexed { index, item ->
            val sweep = (item.total.toFloat() / total) * 360f
            drawArc(
                color = colors.getOrElse(index) { TealPrimary },
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Butt)
            )
            startAngle += sweep
        }
    }
}

@Composable
private fun CategoryRow(
    summary: CategorySummary,
    onClick: () -> Unit
) {
    val color = try {
        Color(android.graphics.Color.parseColor(summary.category.colorHex))
    } catch (_: Exception) {
        TealPrimary
    }

    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(color.copy(0.15f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(summary.category.icon, fontSize = 20.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(summary.category.name, fontWeight = FontWeight.Medium)
                Text(
                    "${"%.1f".format(summary.percentage)}%",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { (summary.percentage / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp),
                    color = color,
                    trackColor = Color.LightGray.copy(0.3f)
                )
            }
            Spacer(Modifier.width(12.dp))
            Text(
                FormatUtils.formatMoney(summary.total),
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
