package com.expensetracker.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val icon: String,          // emoji or resource name
    val colorHex: String,      // e.g. "#4CAF50"
    val sortOrder: Int = 0
)

@Entity(tableName = "receipts")
data class Receipt(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val storeName: String,
    val dateMillis: Long,               // timestamp of purchase
    val totalAmount: Double,
    val imagePath: String? = null,      // local path to receipt photo
    val createdAt: Long = System.currentTimeMillis(),
    val notes: String? = null
)

@Entity(
    tableName = "receipt_items",
    foreignKeys = [
        ForeignKey(
            entity = Receipt::class,
            parentColumns = ["id"],
            childColumns = ["receiptId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("receiptId"), Index("categoryId")]
)
data class ReceiptItem(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val receiptId: String,
    val name: String,
    val quantity: Double = 1.0,
    val price: Double,                  // total price for this line
    val unitPrice: Double? = null,
    val categoryId: String? = null,
    val categoryName: String? = null    // denormalized for convenience
)

// Helper data classes for UI

data class CategorySummary(
    val category: Category,
    val total: Double,
    val percentage: Float,
    val itemCount: Int = 0
)

data class MonthSummary(
    val totalThisMonth: Double,
    val totalLastMonth: Double,
    val categories: List<CategorySummary>,
    val recentReceipts: List<ReceiptWithItems>
)

data class ReceiptWithItems(
    val receipt: Receipt,
    val items: List<ReceiptItem>
)

data class PeriodFilter(
    val type: PeriodType,
    val startMillis: Long,
    val endMillis: Long,
    val label: String
)

enum class PeriodType {
    CURRENT_MONTH,
    PREVIOUS_MONTH,
    LAST_30_DAYS,
    LAST_90_DAYS,
    YEAR_TO_DATE,
    CUSTOM
}
