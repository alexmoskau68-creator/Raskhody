package com.expensetracker.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val TealPrimary = Color(0xFF006D77)
val TealDark = Color(0xFF004C54)
val TealLight = Color(0xFF83C5BE)
val SurfaceLight = Color(0xFFF8F9FA)
val CardWhite = Color(0xFFFFFFFF)

private val LightColorScheme = lightColorScheme(
    primary = TealPrimary,
    onPrimary = Color.White,
    primaryContainer = TealLight,
    onPrimaryContainer = TealDark,
    secondary = Color(0xFF4A6366),
    background = SurfaceLight,
    surface = CardWhite,
    surfaceVariant = Color(0xFFE8EEF0),
    onSurface = Color(0xFF1A1C1E),
    onSurfaceVariant = Color(0xFF5C6668)
)

private val DarkColorScheme = darkColorScheme(
    primary = TealLight,
    onPrimary = TealDark,
    primaryContainer = TealPrimary,
    onPrimaryContainer = Color.White,
    secondary = Color(0xFFB0C4C7),
    background = Color(0xFF0F1416),
    surface = Color(0xFF1A2224),
    surfaceVariant = Color(0xFF2A3336),
    onSurface = Color(0xFFE1E3E4),
    onSurfaceVariant = Color(0xFFA8B2B5)
)

@Composable
fun ExpenseTrackerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
