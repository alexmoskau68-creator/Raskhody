package com.expensetracker.utils

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class OcrResult(
    val storeName: String?,
    val totalAmount: Double?,
    val dateMillis: Long?,
    val items: List<OcrItem>,
    val rawText: String
)

data class OcrItem(
    val name: String,
    val price: Double,
    val quantity: Double = 1.0
)

object ReceiptOcrHelper {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognize(bitmap: Bitmap): OcrResult {
        val image = InputImage.fromBitmap(bitmap, 0)
        val text = suspendCancellableCoroutine { cont ->
            recognizer.process(image)
                .addOnSuccessListener { result ->
                    cont.resume(result.text)
                }
                .addOnFailureListener { e ->
                    cont.resumeWithException(e)
                }
        }
        return parseText(text)
    }

    private fun parseText(raw: String): OcrResult {
        val lines = raw.lines().map { it.trim() }.filter { it.isNotBlank() }

        val storeName = extractStoreName(lines)
        val total = extractTotal(lines)
        val items = extractItems(lines)
        val date = extractDate(lines)

        return OcrResult(
            storeName = storeName,
            totalAmount = total,
            dateMillis = date,
            items = items,
            rawText = raw
        )
    }

    private fun extractStoreName(lines: List<String>): String? {
        // Common Russian store names
        val knownStores = listOf(
            "Дикси", "ДИКСИ", "Пятёрочка", "Пятерочка", "Магнит", "Лента",
            "Ашан", "Перекрёсток", "Перекресток", "ВкусВилл", "Вкусвилл",
            "Аптека", "Ригла", "Столички", "Неофарм", "Горздрав"
        )

        for (line in lines.take(8)) {
            for (store in knownStores) {
                if (line.contains(store, ignoreCase = true)) {
                    return store.replaceFirstChar { it.uppercase() }
                }
            }
            // Often store name is near the top and contains "ООО" or "АО"
            if ((line.contains("ООО") || line.contains("АО") || line.contains("ИП")) && line.length in 5..60) {
                // Try to clean it
                val cleaned = line
                    .replace(Regex("""[«»""]"""), "")
                    .trim()
                if (cleaned.length > 3) return cleaned.take(40)
            }
        }
        return lines.firstOrNull { it.length in 4..40 && !it.any { c -> c.isDigit() } }
    }

    private fun extractTotal(lines: List<String>): Double? {
        // Look for "ИТОГО", "ИТОГО К ОПЛАТЕ", "СУММА" etc.
        val totalKeywords = listOf("ИТОГО К ОПЛАТЕ", "ИТОГО", "СУММА", "ВСЕГО", "К ОПЛАТЕ")

        for (i in lines.indices.reversed()) {
            val line = lines[i].uppercase()
            if (totalKeywords.any { line.contains(it) }) {
                val amount = extractAmountFromLine(lines[i])
                if (amount != null && amount > 0) return amount
                // Sometimes amount is on the next line
                if (i + 1 < lines.size) {
                    val nextAmount = extractAmountFromLine(lines[i + 1])
                    if (nextAmount != null && nextAmount > 0) return nextAmount
                }
            }
        }

        // Fallback: largest number that looks like money near the end
        val candidates = lines.takeLast(15).mapNotNull { extractAmountFromLine(it) }
            .filter { it > 10 }
        return candidates.maxOrNull()
    }

    private fun extractItems(lines: List<String>): List<OcrItem> {
        val items = mutableListOf<OcrItem>()
        val priceRegex = Regex("""(\d+[.,]\d{2})""")

        for (line in lines) {
            // Skip headers and totals
            val upper = line.uppercase()
            if (upper.contains("НАИМЕНОВАНИЕ") || upper.contains("ИТОГО") ||
                upper.contains("КАССА") || upper.contains("КАССИР") ||
                upper.contains("НДС") || upper.contains("СУММА НДС") ||
                line.length < 5
            ) continue

            val prices = priceRegex.findAll(line).map {
                it.groupValues[1].replace(',', '.').toDoubleOrNull()
            }.filterNotNull().toList()

            if (prices.isNotEmpty()) {
                val price = prices.last() // usually the total for the line
                if (price < 1 || price > 100_000) continue

                // Name is everything before the last price-like number
                val namePart = line.substringBeforeLast(prices.last().toString().replace('.', ','))
                    .substringBeforeLast(prices.last().toString())
                    .trim()
                    .replace(Regex("""\s+\d+\s*[xх×]\s*"""), " ")
                    .trim()

                if (namePart.length >= 3) {
                    items.add(OcrItem(name = namePart.take(80), price = price))
                }
            }
        }

        // Limit to reasonable number
        return items.distinctBy { it.name.take(20) }.take(40)
    }

    private fun extractDate(lines: List<String>): Long? {
        // Look for patterns like 08.09.2026 or 08/09/2026
        val dateRegex = Regex("""(\d{2})[./](\d{2})[./](\d{2,4})""")
        for (line in lines) {
            val match = dateRegex.find(line)
            if (match != null) {
                try {
                    val day = match.groupValues[1].toInt()
                    val month = match.groupValues[2].toInt()
                    var year = match.groupValues[3].toInt()
                    if (year < 100) year += 2000
                    if (day in 1..31 && month in 1..12 && year in 2020..2035) {
                        val cal = java.util.Calendar.getInstance()
                        cal.set(year, month - 1, day, 12, 0, 0)
                        cal.set(java.util.Calendar.MILLISECOND, 0)
                        return cal.timeInMillis
                    }
                } catch (_: Exception) {}
            }
        }
        return System.currentTimeMillis()
    }

    private fun extractAmountFromLine(line: String): Double? {
        val regex = Regex("""(\d{1,6}[.,]\d{2})""")
        val matches = regex.findAll(line).toList()
        if (matches.isEmpty()) return null
        // Prefer the last one (usually the total on the right)
        return matches.last().groupValues[1].replace(',', '.').toDoubleOrNull()
    }
}
