package com.expensetracker.ui.screens.add

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.expensetracker.data.model.Category
import com.expensetracker.data.model.Receipt
import com.expensetracker.data.model.ReceiptItem
import com.expensetracker.data.repository.ExpenseRepository
import com.expensetracker.ui.theme.TealDark
import com.expensetracker.ui.theme.TealPrimary
import com.expensetracker.utils.FormatUtils
import com.expensetracker.utils.OcrItem
import com.expensetracker.utils.ReceiptOcrHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddExpenseScreen(
    repository: ExpenseRepository,
    onBack: () -> Unit,
    onSaved: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var step by remember { mutableStateOf(0) } // 0 = choose method, 1 = review/edit
    var isProcessing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    // Form fields
    var storeName by remember { mutableStateOf("") }
    var totalAmount by remember { mutableStateOf("") }
    var dateMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    var items by remember { mutableStateOf<List<EditableItem>>(emptyList()) }
    var imagePath by remember { mutableStateOf<String?>(null) }
    var categories by remember { mutableStateOf<List<Category>>(emptyList()) }

    LaunchedEffect(Unit) {
        categories = repository.getCategoriesOnce()
    }

    // Camera
    val photoFile = remember {
        File(context.cacheDir, "receipt_${System.currentTimeMillis()}.jpg")
    }
    val photoUri = remember {
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", photoFile)
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            scope.launch {
                isProcessing = true
                error = null
                try {
                    val bitmap = withContext(Dispatchers.IO) {
                        BitmapFactory.decodeFile(photoFile.absolutePath)
                    }
                    if (bitmap != null) {
                        processOcr(bitmap, photoFile.absolutePath)
                    }
                } catch (e: Exception) {
                    error = "Ошибка обработки: ${e.message}"
                } finally {
                    isProcessing = false
                }
            }
        }
    }

    // Gallery
    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                isProcessing = true
                error = null
                try {
                    val bitmap = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use {
                            BitmapFactory.decodeStream(it)
                        }
                    }
                    if (bitmap != null) {
                        // Save copy
                        val dest = File(context.cacheDir, "receipt_${System.currentTimeMillis()}.jpg")
                        withContext(Dispatchers.IO) {
                            dest.outputStream().use { out ->
                                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                            }
                        }
                        processOcr(bitmap, dest.absolutePath)
                    }
                } catch (e: Exception) {
                    error = "Ошибка: ${e.message}"
                } finally {
                    isProcessing = false
                }
            }
        }
    }

    suspend fun processOcr(bitmap: Bitmap, path: String) {
        val result = withContext(Dispatchers.Default) {
            ReceiptOcrHelper.recognize(bitmap)
        }
        storeName = result.storeName ?: "Магазин"
        totalAmount = result.totalAmount?.toString() ?: ""
        dateMillis = result.dateMillis ?: System.currentTimeMillis()
        imagePath = path

        val defaultCat = categories.firstOrNull { it.id == "cat_products" }
            ?: categories.firstOrNull()

        items = result.items.map { ocr ->
            EditableItem(
                id = UUID.randomUUID().toString(),
                name = ocr.name,
                price = ocr.price,
                quantity = ocr.quantity,
                categoryId = defaultCat?.id,
                categoryName = defaultCat?.name
            )
        }
        if (items.isEmpty() && result.totalAmount != null) {
            // At least one item with total
            items = listOf(
                EditableItem(
                    id = UUID.randomUUID().toString(),
                    name = "Покупка",
                    price = result.totalAmount,
                    quantity = 1.0,
                    categoryId = defaultCat?.id,
                    categoryName = defaultCat?.name
                )
            )
        }
        step = 1
    }

    fun save() {
        scope.launch {
            isProcessing = true
            try {
                val amount = totalAmount.replace(',', '.').toDoubleOrNull()
                    ?: items.sumOf { it.price }

                val receipt = Receipt(
                    storeName = storeName.ifBlank { "Без названия" },
                    dateMillis = dateMillis,
                    totalAmount = amount,
                    imagePath = imagePath
                )

                val receiptItems = items.map { item ->
                    ReceiptItem(
                        id = item.id,
                        receiptId = receipt.id,
                        name = item.name,
                        quantity = item.quantity,
                        price = item.price,
                        categoryId = item.categoryId,
                        categoryName = item.categoryName
                    )
                }

                repository.insertReceipt(receipt, receiptItems)
                onSaved(receipt.id)
            } catch (e: Exception) {
                error = "Не удалось сохранить: ${e.message}"
            } finally {
                isProcessing = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (step == 0) "Добавить расход" else "Проверка чека") },
                navigationIcon = {
                    IconButton(onClick = {
                        if (step == 1) step = 0 else onBack()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = TealDark,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when {
                isProcessing -> {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(12.dp))
                        Text("Распознаём чек…")
                    }
                }
                step == 0 -> {
                    ChooseMethodContent(
                        onCamera = { cameraLauncher.launch(photoUri) },
                        onGallery = { galleryLauncher.launch("image/*") },
                        onManual = {
                            storeName = ""
                            totalAmount = ""
                            items = listOf(
                                EditableItem(
                                    id = UUID.randomUUID().toString(),
                                    name = "",
                                    price = 0.0,
                                    quantity = 1.0,
                                    categoryId = categories.firstOrNull()?.id,
                                    categoryName = categories.firstOrNull()?.name
                                )
                            )
                            step = 1
                        }
                    )
                }
                else -> {
                    ReviewContent(
                        storeName = storeName,
                        onStoreChange = { storeName = it },
                        totalAmount = totalAmount,
                        onTotalChange = { totalAmount = it },
                        items = items,
                        onItemsChange = { items = it },
                        categories = categories,
                        onSave = { save() },
                        error = error
                    )
                }
            }
        }
    }
}

@Composable
private fun ChooseMethodContent(
    onCamera: () -> Unit,
    onGallery: () -> Unit,
    onManual: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Как добавить расход?",
            fontWeight = FontWeight.SemiBold,
            fontSize = 18.sp,
            color = TealDark
        )
        Spacer(Modifier.height(8.dp))

        MethodCard(
            icon = Icons.Default.PhotoCamera,
            title = "Сканировать чек",
            subtitle = "Сфотографировать чек",
            color = Color(0xFF2196F3),
            onClick = onCamera
        )
        MethodCard(
            icon = Icons.Default.Image,
            title = "Фотогалерея",
            subtitle = "Выбрать фото чека из галереи",
            color = Color(0xFF4CAF50),
            onClick = onGallery
        )
        MethodCard(
            icon = Icons.Default.UploadFile,
            title = "Импорт файла",
            subtitle = "Загрузить PDF или изображение",
            color = Color(0xFFFF9800),
            onClick = onGallery // same for simplicity
        )
        MethodCard(
            icon = Icons.Default.Edit,
            title = "Ручной ввод",
            subtitle = "Введите данные расхода вручную",
            color = Color(0xFF9E9E9E),
            onClick = onManual
        )
    }
}

@Composable
private fun MethodCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(color.copy(0.12f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color)
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                Text(subtitle, fontSize = 13.sp, color = Color.Gray)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Color.Gray)
        }
    }
}

@Composable
private fun ReviewContent(
    storeName: String,
    onStoreChange: (String) -> Unit,
    totalAmount: String,
    onTotalChange: (String) -> Unit,
    items: List<EditableItem>,
    onItemsChange: (List<EditableItem>) -> Unit,
    categories: List<Category>,
    onSave: () -> Unit,
    error: String?
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = storeName,
            onValueChange = onStoreChange,
            label = { Text("Магазин") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = totalAmount,
            onValueChange = onTotalChange,
            label = { Text("Сумма итого") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(Modifier.height(20.dp))
        Text("Товары", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)

        items.forEachIndexed { index, item ->
            ItemEditor(
                item = item,
                categories = categories,
                onChange = { updated ->
                    val newList = items.toMutableList()
                    newList[index] = updated
                    onItemsChange(newList)
                },
                onDelete = {
                    onItemsChange(items.filterIndexed { i, _ -> i != index })
                }
            )
        }

        TextButton(
            onClick = {
                onItemsChange(
                    items + EditableItem(
                        id = UUID.randomUUID().toString(),
                        name = "",
                        price = 0.0,
                        quantity = 1.0,
                        categoryId = categories.firstOrNull()?.id,
                        categoryName = categories.firstOrNull()?.name
                    )
                )
            }
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(4.dp))
            Text("Добавить товар")
        }

        if (error != null) {
            Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp))
        }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onSave,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = TealPrimary)
        ) {
            Text("Сохранить", fontSize = 16.sp)
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun ItemEditor(
    item: EditableItem,
    categories: List<Category>,
    onChange: (EditableItem) -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F9FA))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = item.name,
                    onValueChange = { onChange(item.copy(name = it)) },
                    label = { Text("Название") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = Color.Red.copy(0.7f))
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = if (item.price == 0.0) "" else item.price.toString(),
                    onValueChange = {
                        onChange(item.copy(price = it.replace(',', '.').toDoubleOrNull() ?: 0.0))
                    },
                    label = { Text("Цена") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedTextField(
                        value = item.categoryName ?: "Категория",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Категория") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expanded = true },
                        trailingIcon = {
                            Icon(Icons.Default.ArrowDropDown, null)
                        }
                    )
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text("${cat.icon} ${cat.name}") },
                                onClick = {
                                    onChange(item.copy(categoryId = cat.id, categoryName = cat.name))
                                    expanded = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

data class EditableItem(
    val id: String,
    val name: String,
    val price: Double,
    val quantity: Double,
    val categoryId: String?,
    val categoryName: String?
)
