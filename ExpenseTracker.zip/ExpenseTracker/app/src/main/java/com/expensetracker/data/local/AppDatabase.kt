package com.expensetracker.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.expensetracker.data.model.Category
import com.expensetracker.data.model.Receipt
import com.expensetracker.data.model.ReceiptItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Category::class, Receipt::class, ReceiptItem::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun categoryDao(): CategoryDao
    abstract fun receiptDao(): ReceiptDao
    abstract fun receiptItemDao(): ReceiptItemDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "expense_tracker.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Pre-populate default categories
                            INSTANCE?.let { database ->
                                CoroutineScope(Dispatchers.IO).launch {
                                    seedCategories(database.categoryDao())
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedCategories(dao: CategoryDao) {
            val defaults = listOf(
                Category(
                    id = "cat_products",
                    name = "Продукты",
                    icon = "🛒",
                    colorHex = "#2196F3",
                    sortOrder = 0
                ),
                Category(
                    id = "cat_health",
                    name = "Здоровье и аптеки",
                    icon = "💊",
                    colorHex = "#4CAF50",
                    sortOrder = 1
                ),
                Category(
                    id = "cat_alcohol",
                    name = "Алкогольные напитки",
                    icon = "🍷",
                    colorHex = "#FF9800",
                    sortOrder = 2
                ),
                Category(
                    id = "cat_transport",
                    name = "Транспорт",
                    icon = "🚌",
                    colorHex = "#9C27B0",
                    sortOrder = 3
                ),
                Category(
                    id = "cat_cafe",
                    name = "Кафе и рестораны",
                    icon = "☕",
                    colorHex = "#E91E63",
                    sortOrder = 4
                ),
                Category(
                    id = "cat_other",
                    name = "Другое",
                    icon = "📦",
                    colorHex = "#607D8B",
                    sortOrder = 99
                )
            )
            dao.insertAll(defaults)
        }
    }
}
