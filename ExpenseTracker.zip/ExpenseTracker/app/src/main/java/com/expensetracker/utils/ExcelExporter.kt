package com.expensetracker.utils

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.expensetracker.data.model.ReceiptWithItems
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.IndexedColors
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExcelExporter {

    fun exportReceipts(
        context: Context,
        receipts: List<ReceiptWithItems>,
        fileName: String = "расходы_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())}.xlsx"
    ): Uri? {
        return try {
            val workbook = XSSFWorkbook()

            // Sheet 1: Summary by receipts
            val sheet1 = workbook.createSheet("Чеки")
            val headerStyle = workbook.createCellStyle().apply {
                fillForegroundColor = IndexedColors.DARK_TEAL.index
                fillPattern = FillPatternType.SOLID_FOREGROUND
                val font = workbook.createFont().apply {
                    bold = true
                    color = IndexedColors.WHITE.index
                }
                setFont(font)
            }

            val headers1 = listOf("Дата", "Магазин", "Сумма", "Кол-во товаров", "Заметки")
            val headerRow1 = sheet1.createRow(0)
            headers1.forEachIndexed { i, title ->
                headerRow1.createCell(i).apply {
                    setCellValue(title)
                    cellStyle = headerStyle
                }
            }

            receipts.forEachIndexed { index, rwi ->
                val row = sheet1.createRow(index + 1)
                row.createCell(0).setCellValue(FormatUtils.formatDate(rwi.receipt.dateMillis))
                row.createCell(1).setCellValue(rwi.receipt.storeName)
                row.createCell(2).setCellValue(rwi.receipt.totalAmount)
                row.createCell(3).setCellValue(rwi.items.size.toDouble())
                row.createCell(4).setCellValue(rwi.receipt.notes ?: "")
            }

            // Auto size
            for (i in headers1.indices) sheet1.autoSizeColumn(i)

            // Sheet 2: All items
            val sheet2 = workbook.createSheet("Товары")
            val headers2 = listOf("Дата", "Магазин", "Товар", "Количество", "Цена", "Категория")
            val headerRow2 = sheet2.createRow(0)
            headers2.forEachIndexed { i, title ->
                headerRow2.createCell(i).apply {
                    setCellValue(title)
                    cellStyle = headerStyle
                }
            }

            var rowIdx = 1
            receipts.forEach { rwi ->
                rwi.items.forEach { item ->
                    val row = sheet2.createRow(rowIdx++)
                    row.createCell(0).setCellValue(FormatUtils.formatDate(rwi.receipt.dateMillis))
                    row.createCell(1).setCellValue(rwi.receipt.storeName)
                    row.createCell(2).setCellValue(item.name)
                    row.createCell(3).setCellValue(item.quantity)
                    row.createCell(4).setCellValue(item.price)
                    row.createCell(5).setCellValue(item.categoryName ?: "")
                }
            }
            for (i in headers2.indices) sheet2.autoSizeColumn(i)

            // Save file
            val dir = File(context.cacheDir, "exports").apply { mkdirs() }
            val file = File(dir, fileName)
            FileOutputStream(file).use { workbook.write(it) }
            workbook.close()

            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
