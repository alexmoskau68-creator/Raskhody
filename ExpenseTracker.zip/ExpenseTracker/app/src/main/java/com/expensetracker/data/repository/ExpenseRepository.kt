package com.expensetracker.data.repository

import android.content.Context
import com.expensetracker.data.local.AppDatabase
import com.expensetracker.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import java.util.Calendar

class ExpenseRepository(context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val categoryDao = db.categoryDao()
    private val receiptDao = db.receiptDao()
    private val itemDao = db.receiptItemDao()

    // Categories
    fun getCategories(): Flow<List<Category>> = categoryDao.getAll()

    suspend fun getCategoriesOnce(): List<Category> = categoryDao.getAllOnce()

    // Receipts
    fun getAllReceipts(): Flow<List<Receipt>> = receiptDao.getAll()

    fun getRecentReceipts(limit: Int = 15): Flow<List<Receipt>> = receiptDao.getRecent(limit)

    suspend fun getReceiptById(id: String): Receipt? = receiptDao.getById(id)

    suspend fun getReceiptWithItems(id: String): ReceiptWithItems? {
        val receipt = receiptDao.getById(id) ?: return null
        val items = itemDao.getByReceiptOnce(id)
        return ReceiptWithItems(receipt, items)
    }

    fun getReceiptsByPeriod(start: Long, end: Long): Flow<List<Receipt>> =
        receiptDao.getByPeriod(start, end)

    suspend fun insertReceipt(receipt: Receipt, items: List<ReceiptItem>) {
        receiptDao.insert(receipt)
        if (items.isNotEmpty()) {
            itemDao.insertAll(items)
        }
    }

    suspend fun updateReceipt(receipt: Receipt) = receiptDao.update(receipt)

    suspend fun deleteReceipt(id: String) {
        itemDao.deleteByReceipt(id)
        receiptDao.deleteById(id)
    }

    suspend fun updateItem(item: ReceiptItem) = itemDao.update(item)

    suspend fun insertItem(item: ReceiptItem) = itemDao.insert(item)

    suspend fun deleteItem(item: ReceiptItem) = itemDao.delete(item)

    // Summaries
    suspend fun getMonthSummary(): MonthSummary {
        val (thisStart, thisEnd) = getCurrentMonthRange()
        val (lastStart, lastEnd) = getPreviousMonthRange()

        val thisReceipts = receiptDao.getByPeriodOnce(thisStart, thisEnd)
        val lastReceipts = receiptDao.getByPeriodOnce(lastStart, lastEnd)

        val totalThis = thisReceipts.sumOf { it.totalAmount }
        val totalLast = lastReceipts.sumOf { it.totalAmount }

        val categories = categoryDao.getAllOnce()
        val categorySummaries = mutableListOf<CategorySummary>()

        for (cat in categories) {
            val items = itemDao.getByCategoryAndPeriod(cat.id, thisStart, thisEnd)
            val sum = items.sumOf { it.price }
            if (sum > 0) {
                val pct = if (totalThis > 0) (sum / totalThis * 100).toFloat() else 0f
                categorySummaries.add(
                    CategorySummary(cat, sum, pct, items.size)
                )
            }
        }

        // Sort by total descending
        categorySummaries.sortByDescending { it.total }

        // Recent
        val recent = receiptDao.getRecent(10).first().map { r ->
            val items = itemDao.getByReceiptOnce(r.id)
            ReceiptWithItems(r, items)
        }

        return MonthSummary(totalThis, totalLast, categorySummaries, recent)
    }

    suspend fun getCategorySummaryForPeriod(
        categoryId: String,
        start: Long,
        end: Long
    ): Pair<Double, List<ReceiptItem>> {
        val items = itemDao.getByCategoryAndPeriod(categoryId, start, end)
        val total = items.sumOf { it.price }
        return total to items
    }

    suspend fun getCategoryTotalsForPeriod(start: Long, end: Long): List<CategorySummary> {
        val categories = categoryDao.getAllOnce()
        val receipts = receiptDao.getByPeriodOnce(start, end)
        val totalAll = receipts.sumOf { it.totalAmount }

        return categories.mapNotNull { cat ->
            val items = itemDao.getByCategoryAndPeriod(cat.id, start, end)
            val sum = items.sumOf { it.price }
            if (sum > 0) {
                val pct = if (totalAll > 0) (sum / totalAll * 100).toFloat() else 0f
                CategorySummary(cat, sum, pct, items.size)
            } else null
        }.sortedByDescending { it.total }
    }

    // Helpers for date ranges
    fun getCurrentMonthRange(): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis

        cal.add(Calendar.MONTH, 1)
        cal.add(Calendar.MILLISECOND, -1)
        val end = cal.timeInMillis
        return start to end
    }

    fun getPreviousMonthRange(): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.add(Calendar.MONTH, -1)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis

        cal.add(Calendar.MONTH, 1)
        cal.add(Calendar.MILLISECOND, -1)
        val end = cal.timeInMillis
        return start to end
    }

    fun getLastDaysRange(days: Int): Pair<Long, Long> {
        val end = System.currentTimeMillis()
        val start = end - days * 24L * 60 * 60 * 1000
        return start to end
    }

    fun getYearToDateRange(): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_YEAR, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis to System.currentTimeMillis()
    }
}
