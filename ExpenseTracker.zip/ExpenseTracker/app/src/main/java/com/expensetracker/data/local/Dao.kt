package com.expensetracker.data.local

import androidx.room.*
import com.expensetracker.data.model.Category
import com.expensetracker.data.model.Receipt
import com.expensetracker.data.model.ReceiptItem
import kotlinx.coroutines.flow.Flow

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY sortOrder ASC")
    fun getAll(): Flow<List<Category>>

    @Query("SELECT * FROM categories ORDER BY sortOrder ASC")
    suspend fun getAllOnce(): List<Category>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(category: Category)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(categories: List<Category>)

    @Update
    suspend fun update(category: Category)

    @Delete
    suspend fun delete(category: Category)
}

@Dao
interface ReceiptDao {
    @Query("SELECT * FROM receipts ORDER BY dateMillis DESC")
    fun getAll(): Flow<List<Receipt>>

    @Query("SELECT * FROM receipts WHERE id = :id")
    suspend fun getById(id: String): Receipt?

    @Query("SELECT * FROM receipts WHERE dateMillis BETWEEN :start AND :end ORDER BY dateMillis DESC")
    fun getByPeriod(start: Long, end: Long): Flow<List<Receipt>>

    @Query("SELECT * FROM receipts WHERE dateMillis BETWEEN :start AND :end ORDER BY dateMillis DESC")
    suspend fun getByPeriodOnce(start: Long, end: Long): List<Receipt>

    @Query("SELECT * FROM receipts ORDER BY dateMillis DESC LIMIT :limit")
    fun getRecent(limit: Int = 20): Flow<List<Receipt>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(receipt: Receipt)

    @Update
    suspend fun update(receipt: Receipt)

    @Delete
    suspend fun delete(receipt: Receipt)

    @Query("DELETE FROM receipts WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface ReceiptItemDao {
    @Query("SELECT * FROM receipt_items WHERE receiptId = :receiptId")
    fun getByReceipt(receiptId: String): Flow<List<ReceiptItem>>

    @Query("SELECT * FROM receipt_items WHERE receiptId = :receiptId")
    suspend fun getByReceiptOnce(receiptId: String): List<ReceiptItem>

    @Query("SELECT * FROM receipt_items WHERE categoryId = :categoryId")
    suspend fun getByCategory(categoryId: String): List<ReceiptItem>

    @Query("""
        SELECT ri.* FROM receipt_items ri
        INNER JOIN receipts r ON ri.receiptId = r.id
        WHERE ri.categoryId = :categoryId
        AND r.dateMillis BETWEEN :start AND :end
        ORDER BY r.dateMillis DESC
    """)
    suspend fun getByCategoryAndPeriod(categoryId: String, start: Long, end: Long): List<ReceiptItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: ReceiptItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ReceiptItem>)

    @Update
    suspend fun update(item: ReceiptItem)

    @Delete
    suspend fun delete(item: ReceiptItem)

    @Query("DELETE FROM receipt_items WHERE receiptId = :receiptId")
    suspend fun deleteByReceipt(receiptId: String)
}
