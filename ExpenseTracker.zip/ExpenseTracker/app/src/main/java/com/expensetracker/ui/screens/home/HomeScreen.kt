package com.expensetracker.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.PieChart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.expensetracker.data.model.CategorySummary
import com.expensetracker.data.model.ReceiptWithItems
import com.expensetracker.ui.theme.TealDark
import com.expensetracker.ui.theme.TealPrimary
import com.expensetracker.utils.FormatUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onAddClick: () -> Unit,
    onReceiptClick: (String) -> Unit,
    onCategoriesClick: () -> Unit,
    onCategoryClick: (String, Long, Long) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddClick,
                containerColor = TealPrimary,
                contentColor = Color.White,
                shape = CircleShape
            ) {
                Icon(Icons.Default.Add, contentDescription = "Добавить")
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when {
                uiState.isLoading -> {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                }
                uiState.error != null -> {
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(uiState.error ?: "")
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { viewModel.refresh() }) {
                            Text("Повторить")
                        }
                    }
                }
                uiState.summary != null -> {
                    HomeContent(
                        summary = uiState.summary!!,
                        onReceiptClick = onReceiptClick,
                        onCategoriesClick = onCategoriesClick,
                        onCategoryClick = onCategoryClick,
                        onRefresh = { viewModel.refresh() }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeContent(
    summary: com.expensetracker.data.model.MonthSummary,
    onReceiptClick: (String) -> Unit,
    onCategoriesClick: () -> Unit,
    onCategoryClick: (String, Long, Long) -> Unit,
    onRefresh: () -> Unit
) {
    val (start, end) = rememberCurrentMonthRange()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 88.dp)
    ) {
        // Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(TealDark, TealPrimary)
                        )
                    )
                    .padding(top = 48.dp, bottom = 32.dp, start = 20.dp, end = 20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Home,
                            contentDescription = null,
                            tint = Color.White.copy(alpha = 0.9f),
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.White.copy(0.15f), CircleShape)
                                .padding(8.dp)
                        )
                        Text(
                            "Прошлый месяц",
                            color = Color.White.copy(0.8f),
                            fontSize = 13.sp
                        )
                    }

                    Spacer(Modifier.height(20.dp))

                    Text(
                        "Траты в этом месяце",
                        color = Color.White.copy(0.85f),
                        fontSize = 14.sp
                    )
                    Text(
                        FormatUtils.formatMoney(summary.totalThisMonth),
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        FormatUtils.formatMoney(summary.totalLastMonth),
                        color = Color.White.copy(0.7f),
                        fontSize = 14.sp,
                        modifier = Modifier.align(Alignment.End)
                    )
                }
            }
        }

        // Categories card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = (-20).dp)
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Основные категории",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp,
                            color = TealDark
                        )
                        TextButton(onClick = onCategoriesClick) {
                            Icon(
                                Icons.Outlined.PieChart,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text("Все")
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        summary.categories.take(3).forEach { catSum ->
                            CategoryMiniCard(
                                summary = catSum,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    onCategoryClick(catSum.category.id, start, end)
                                }
                            )
                        }
                        // Fill empty if less than 3
                        repeat(3 - summary.categories.take(3).size) {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // Recent expenses
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Недавние расходы",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    color = TealDark
                )
            }
        }

        items(summary.recentReceipts, key = { it.receipt.id }) { rwi ->
            ReceiptListItem(
                receiptWithItems = rwi,
                onClick = { onReceiptClick(rwi.receipt.id) }
            )
        }

        if (summary.recentReceipts.isEmpty()) {
            item {
                Text(
                    "Пока нет расходов.\nНажмите + чтобы добавить чек.",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    color = Color.Gray,
                    fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
private fun CategoryMiniCard(
    summary: CategorySummary,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val color = try {
        Color(android.graphics.Color.parseColor(summary.category.colorHex))
    } catch (_: Exception) {
        TealPrimary
    }

    Card(
        modifier = modifier
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F7F8)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(color.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(summary.category.icon, fontSize = 18.sp)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                FormatUtils.formatMoney(summary.total).replace(" ₽", " ₽"),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                maxLines = 1
            )
            Spacer(Modifier.height(4.dp))
            // Progress
            LinearProgressIndicator(
                progress = { (summary.percentage / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = color,
                trackColor = Color.LightGray.copy(0.3f)
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "${"%.1f".format(summary.percentage)}%",
                fontSize = 11.sp,
                color = Color.Gray
            )
            Text(
                summary.category.name,
                fontSize = 11.sp,
                color = Color.DarkGray,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ReceiptListItem(
    receiptWithItems: ReceiptWithItems,
    onClick: () -> Unit
) {
    val receipt = receiptWithItems.receipt
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Thumbnail placeholder
        Box(
            modifier = Modifier
                .size(44.dp)
                .background(Color(0xFFE8EEF0), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text("🧾", fontSize = 20.sp)
        }

        Spacer(Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                receipt.storeName,
                fontWeight = FontWeight.Medium,
                fontSize = 15.sp
            )
            Text(
                FormatUtils.formatDateShort(receipt.dateMillis),
                fontSize = 13.sp,
                color = Color.Gray
            )
        }

        Text(
            FormatUtils.formatMoney(receipt.totalAmount),
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp
        )
    }
    HorizontalDivider(
        modifier = Modifier.padding(start = 78.dp),
        color = Color(0xFFEEEEEE)
    )
}

@Composable
private fun rememberCurrentMonthRange(): Pair<Long, Long> {
    val cal = java.util.Calendar.getInstance()
    cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
    cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
    cal.set(java.util.Calendar.MINUTE, 0)
    cal.set(java.util.Calendar.SECOND, 0)
    cal.set(java.util.Calendar.MILLISECOND, 0)
    val start = cal.timeInMillis
    cal.add(java.util.Calendar.MONTH, 1)
    cal.add(java.util.Calendar.MILLISECOND, -1)
    return start to cal.timeInMillis
}
