package com.expensetracker.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.expensetracker.ExpenseTrackerApp
import com.expensetracker.data.repository.ExpenseRepository
import com.expensetracker.ui.screens.add.AddExpenseScreen
import com.expensetracker.ui.screens.categories.CategoriesScreen
import com.expensetracker.ui.screens.categorydetail.CategoryDetailScreen
import com.expensetracker.ui.screens.home.HomeScreen
import com.expensetracker.ui.screens.home.HomeViewModel
import com.expensetracker.ui.screens.receipt.ReceiptDetailScreen

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Categories : Screen("categories")
    data object AddExpense : Screen("add_expense")
    data object ReceiptDetail : Screen("receipt/{receiptId}") {
        fun createRoute(id: String) = "receipt/$id"
    }
    data object CategoryDetail : Screen("category/{categoryId}/{start}/{end}") {
        fun createRoute(categoryId: String, start: Long, end: Long) =
            "category/$categoryId/$start/$end"
    }
}

@Composable
fun AppNavGraph() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val repository = remember {
        (context.applicationContext as ExpenseTrackerApp).repository
    }

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            val viewModel: HomeViewModel = viewModel(
                factory = HomeViewModel.Factory(repository)
            )
            HomeScreen(
                viewModel = viewModel,
                onAddClick = { navController.navigate(Screen.AddExpense.route) },
                onReceiptClick = { id ->
                    navController.navigate(Screen.ReceiptDetail.createRoute(id))
                },
                onCategoriesClick = {
                    navController.navigate(Screen.Categories.route)
                },
                onCategoryClick = { categoryId, start, end ->
                    navController.navigate(
                        Screen.CategoryDetail.createRoute(categoryId, start, end)
                    )
                }
            )
        }

        composable(Screen.Categories.route) {
            CategoriesScreen(
                repository = repository,
                onBack = { navController.popBackStack() },
                onCategoryClick = { categoryId, start, end ->
                    navController.navigate(
                        Screen.CategoryDetail.createRoute(categoryId, start, end)
                    )
                }
            )
        }

        composable(Screen.AddExpense.route) {
            AddExpenseScreen(
                repository = repository,
                onBack = { navController.popBackStack() },
                onSaved = { receiptId ->
                    navController.popBackStack()
                    navController.navigate(Screen.ReceiptDetail.createRoute(receiptId))
                }
            )
        }

        composable(
            route = Screen.ReceiptDetail.route,
            arguments = listOf(navArgument("receiptId") { type = NavType.StringType })
        ) { backStackEntry ->
            val receiptId = backStackEntry.arguments?.getString("receiptId") ?: return@composable
            ReceiptDetailScreen(
                receiptId = receiptId,
                repository = repository,
                onBack = { navController.popBackStack() },
                onDeleted = { navController.popBackStack() }
            )
        }

        composable(
            route = Screen.CategoryDetail.route,
            arguments = listOf(
                navArgument("categoryId") { type = NavType.StringType },
                navArgument("start") { type = NavType.LongType },
                navArgument("end") { type = NavType.LongType }
            )
        ) { backStackEntry ->
            val categoryId = backStackEntry.arguments?.getString("categoryId") ?: return@composable
            val start = backStackEntry.arguments?.getLong("start") ?: 0L
            val end = backStackEntry.arguments?.getLong("end") ?: 0L
            CategoryDetailScreen(
                categoryId = categoryId,
                startMillis = start,
                endMillis = end,
                repository = repository,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
